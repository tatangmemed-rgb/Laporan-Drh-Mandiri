# Laporan DRH Mandiri

Aplikasi Android untuk pencatatan dan pembuatan laporan kegiatan Dokter Hewan Mandiri.

## Perbaikan utama
- Penyimpanan kegiatan menggunakan Room + transaksi database agar input tidak hilang.
- Rentang laporan dapat dipilih dari bulan A sampai bulan B, termasuk beberapa bulan.
- Setiap bulan selalu dimulai pada halaman baru pada PDF/DOC/JPG.
- Tanda tangan dokter dibuat langsung di aplikasi dan dapat digunakan untuk satu atau banyak bulan.
- Cadangkan dan pulihkan seluruh data.
- Impor JPG lama sebagai arsip legacy agar hasil laporan lama tetap tersimpan.
- Ekspor laporan ke JPG, PDF, dan DOC.

## Build APK
Jalankan:
`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan impor JPG
JPG lama dimasukkan ke Arsip Legacy. Karena JPG adalah gambar hasil laporan, aplikasi tidak menjamin semua teks dapat dikonversi otomatis menjadi data kegiatan terstruktur. Arsip JPG tetap tersimpan dan dapat dibuka kembali di aplikasi.
