package id.mediarta.laporandrh.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activities")
data class ActivityEntity(
    @PrimaryKey val id: String,
    val dateMillis: Long,
    val title: String,
    val location: String,
    val description: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "doctor")
data class DoctorEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val registration: String = "",
    val signaturePath: String? = null
)

@Entity(tableName = "legacy_images")
data class LegacyImageEntity(
    @PrimaryKey val id: String,
    val monthKey: String,
    val filePath: String,
    val note: String = ""
)

@Dao
interface AppDao {
    @Query("SELECT * FROM activities ORDER BY dateMillis DESC")
    fun activities(): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities WHERE dateMillis BETWEEN :from AND :to ORDER BY dateMillis ASC")
    suspend fun activitiesBetween(from: Long, to: Long): List<ActivityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveActivity(item: ActivityEntity)

    @Delete suspend fun deleteActivity(item: ActivityEntity)

    @Query("SELECT * FROM doctor WHERE id=1")
    fun doctor(): Flow<DoctorEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDoctor(item: DoctorEntity)

    @Query("SELECT * FROM legacy_images ORDER BY monthKey DESC")
    fun legacyImages(): Flow<List<LegacyImageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLegacy(item: LegacyImageEntity)

    @Query("SELECT * FROM activities")
    suspend fun allActivities(): List<ActivityEntity>

    @Query("SELECT * FROM legacy_images")
    suspend fun allLegacy(): List<LegacyImageEntity>

    @Query("DELETE FROM activities") suspend fun clearActivities()
    @Query("DELETE FROM legacy_images") suspend fun clearLegacy()
    @Query("DELETE FROM doctor") suspend fun clearDoctor()
}

@Database(entities = [ActivityEntity::class, DoctorEntity::class, LegacyImageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, AppDatabase::class.java, "laporan_drh.db")
                .fallbackToDestructiveMigration()
                .build().also { INSTANCE = it }
        }
    }
}
