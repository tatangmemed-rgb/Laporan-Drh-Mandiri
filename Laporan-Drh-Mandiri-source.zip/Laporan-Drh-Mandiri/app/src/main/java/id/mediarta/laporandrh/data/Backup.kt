package id.mediarta.laporandrh.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

@Serializable data class BackupData(
    val activities: List<ActivityBackup>,
    val doctor: DoctorBackup?,
    val legacy: List<LegacyBackup>
)
@Serializable data class ActivityBackup(val id:String,val dateMillis:Long,val title:String,val location:String,val description:String,val updatedAt:Long)
@Serializable data class DoctorBackup(val name:String,val registration:String,val signaturePath:String?)
@Serializable data class LegacyBackup(val id:String,val monthKey:String,val filePath:String,val note:String)

class BackupManager(private val context: Context, private val dao: AppDao) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    suspend fun writeBackup(file: File) {
        val d = dao.doctor().firstValue()
        val data = BackupData(
            dao.allActivities().map { ActivityBackup(it.id,it.dateMillis,it.title,it.location,it.description,it.updatedAt) },
            d?.let { DoctorBackup(it.name,it.registration,it.signaturePath) },
            dao.allLegacy().map { LegacyBackup(it.id,it.monthKey,it.filePath,it.note) }
        )
        file.writeText(json.encodeToString(data))
    }

    suspend fun restore(file: File) {
        val data = json.decodeFromString<BackupData>(file.readText())
        dao.clearActivities(); dao.clearLegacy(); dao.clearDoctor()
        data.activities.forEach { dao.saveActivity(ActivityEntity(it.id,it.dateMillis,it.title,it.location,it.description,it.updatedAt)) }
        data.doctor?.let { dao.saveDoctor(DoctorEntity(name=it.name,registration=it.registration,signaturePath=it.signaturePath)) }
        data.legacy.forEach { dao.saveLegacy(LegacyImageEntity(it.id,it.monthKey,it.filePath,it.note)) }
    }
}
suspend fun <T> kotlinx.coroutines.flow.Flow<T>.firstValue(): T = kotlinx.coroutines.flow.first(this)
