package id.mediarta.laporandrh

import android.graphics.*
import android.graphics.pdf.PdfDocument
import id.mediarta.laporandrh.data.ActivityEntity
import id.mediarta.laporandrh.data.DoctorEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object ReportExporter {
    private val monthFmt=SimpleDateFormat("MMMM yyyy",Locale("id","ID"))
    private val dayFmt=SimpleDateFormat("dd-MM-yyyy",Locale.US)

    private fun months(data:List<ActivityEntity>): LinkedHashMap<String,List<ActivityEntity>> {
        val m=LinkedHashMap<String,MutableList<ActivityEntity>>()
        data.forEach{a->val k=SimpleDateFormat("yyyy-MM",Locale.US).format(Date(a.dateMillis));m.getOrPut(k){mutableListOf()}.add(a)}
        return LinkedHashMap(m)
    }
    fun pdf(dir:File,base:String,data:List<ActivityEntity>,doctor:DoctorEntity?):File{
        val f=File(dir,"$base.pdf");val doc=PdfDocument();var pageNo=1
        months(data).forEach{(month,items)->
            val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo++).create()); drawPage(page.canvas,month,items,doctor);doc.finishPage(page)
        }
        if(data.isEmpty()){val p=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());drawPage(p.canvas,base,emptyList(),doctor);doc.finishPage(p)}
        FileOutputStream(f).use{doc.writeTo(it)};doc.close();return f
    }
    fun jpg(dir:File,base:String,data:List<ActivityEntity>,doctor:DoctorEntity?):File{
        val pages=months(data)
        // Satu bulan = satu file JPG, sehingga bulan baru tidak pernah berada di bawah bulan sebelumnya.
        val source = if (pages.isEmpty()) linkedMapOf(base to emptyList()) else pages
        var first: File? = null
        source.forEach { (month, items) ->
            val safe = month.replace("/", "-")
            val target = File(dir, "${base}_${safe}.jpg")
            val out = Bitmap.createBitmap(1240,1754,Bitmap.Config.ARGB_8888)
            drawPage(Canvas(out), month, items, doctor)
            FileOutputStream(target).use { out.compress(Bitmap.CompressFormat.JPEG,95,it) }
            if (first == null) first = target
        }
        return first!!
    }
    fun doc(dir:File,base:String,data:List<ActivityEntity>,doctor:DoctorEntity?):File{
        val f=File(dir,"$base.doc")
        val sb=StringBuilder("<html><head><meta charset='utf-8'></head><body>")
        months(data).forEach{(m,items)->
            sb.append("<div style='page-break-after:always'><h1>LAPORAN KEGIATAN DOKTER HEWAN</h1><h2>$m</h2><ol>")
            items.forEach{a->sb.append("<li><b>${esc(a.title)}</b><br>${dayFmt.format(Date(a.dateMillis))}<br>${esc(a.location)}<br>${esc(a.description)}</li><br>")}
            doctor?.let{sb.append("<br><br><p>Dokter Hewan</p><p><b>${esc(it.name)}</b><br>${esc(it.registration)}</p>")}
            sb.append("</div>")
        };sb.append("</body></html>");f.writeText(sb.toString());return f
    }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
    private fun drawPage(c:Canvas,month:String,items:List<ActivityEntity>,doctor:DoctorEntity?){
        c.drawColor(Color.WHITE);val title=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(30,90,70);textSize=34f;typeface=Typeface.DEFAULT_BOLD}
        val text=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.DKGRAY;textSize=22f}
        c.drawText("LAPORAN KEGIATAN DOKTER HEWAN MANDIRI",60f,80f,title);c.drawText(month,60f,125f,text)
        var y=180f;items.forEachIndexed{idx,a->
            c.drawText("${idx+1}. ${a.title}",60f,y,text);y+=30;c.drawText("Tanggal: ${dayFmt.format(Date(a.dateMillis))}",85f,y,text);y+=28
            if(a.location.isNotBlank()){c.drawText("Lokasi: ${a.location}",85f,y,text);y+=28}
            if(a.description.isNotBlank()){c.drawText("Keterangan: ${a.description}",85f,y,text);y+=35}
            y+=12
        }
        doctor?.let{d->if(y<1350)y=1350f;c.drawText("Dokter Hewan,",800f,y,text);y+=45
            d.signaturePath?.let{p->runCatching{BitmapFactory.decodeFile(p)}.getOrNull()?.let{b->c.drawBitmap(b,null,RectF(780f,y,1120f,y+150),null);y+=165}}
            c.drawText(d.name,800f,y,text);y+=30;if(d.registration.isNotBlank())c.drawText(d.registration,800f,y,text)}
    }
}
