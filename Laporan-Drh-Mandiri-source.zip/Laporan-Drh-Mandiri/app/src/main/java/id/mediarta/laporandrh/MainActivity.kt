package id.mediarta.laporandrh

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import id.mediarta.laporandrh.data.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2F6B59))) { App() } }
    }
}

class AppVM(private val context: Context): androidx.lifecycle.ViewModel() {
    private val dao = AppDatabase.get(context).dao()
    val activities = dao.activities()
    val doctor = dao.doctor()
    val legacy = dao.legacyImages()
    private val backup = BackupManager(context, dao)

    suspend fun saveActivity(date:Long,title:String,location:String,description:String) {
        require(title.isNotBlank()) { "Nama kegiatan wajib diisi" }
        dao.saveActivity(ActivityEntity(UUID.randomUUID().toString(), date, title.trim(), location.trim(), description.trim()))
    }
    suspend fun deleteActivity(item: ActivityEntity) = dao.deleteActivity(item)
    suspend fun saveDoctor(name:String,reg:String) = dao.saveDoctor(DoctorEntity(name=name,registration=reg,signaturePath=doctor.firstValue()?.signaturePath))
    suspend fun saveSignature(bitmap: Bitmap) {
        val f = File(context.filesDir, "signature.png")
        FileOutputStream(f).use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }
        val old = doctor.firstValue() ?: DoctorEntity()
        dao.saveDoctor(old.copy(signaturePath=f.absolutePath))
    }
    suspend fun backup(uri: Uri) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            val tmp = File.createTempFile("backup",".json",context.cacheDir)
            backup.writeBackup(tmp); tmp.inputStream().copyTo(out); tmp.delete()
        }
    }
    suspend fun restore(uri: Uri) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val tmp = File.createTempFile("restore",".json",context.cacheDir)
            tmp.outputStream().use { input.copyTo(it) }; backup.restore(tmp); tmp.delete()
        }
    }
    suspend fun importLegacy(uri:Uri, monthKey:String, note:String) {
        val ext = "jpg"
        val f = File(context.filesDir, "legacy_${UUID.randomUUID()}.$ext")
        context.contentResolver.openInputStream(uri)?.use { it.copyTo(f.outputStream()) }
        dao.saveLegacy(LegacyImageEntity(UUID.randomUUID().toString(),monthKey,f.absolutePath,note))
    }
    suspend fun report(fromMonth:String,toMonth:String,format:String): File {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.US)
        val cal = Calendar.getInstance()
        cal.time = sdf.parse(fromMonth)!!
        cal.set(Calendar.DAY_OF_MONTH,1); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0)
        val from = cal.timeInMillis
        cal.time = sdf.parse(toMonth)!!
        cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH)); cal.set(Calendar.HOUR_OF_DAY,23); cal.set(Calendar.MINUTE,59); cal.set(Calendar.SECOND,59)
        val to = cal.timeInMillis
        val data = dao.activitiesBetween(from,to)
        val doc = doctor.firstValue()
        val outDir = File(context.getExternalFilesDir(null),"reports").apply { mkdirs() }
        val base = "Laporan_DRH_${fromMonth}_sampai_${toMonth}"
        return when(format) {
            "PDF" -> ReportExporter.pdf(outDir,base,data,doc)
            "DOC" -> ReportExporter.doc(outDir,base,data,doc)
            else -> ReportExporter.jpg(outDir,base,data,doc)
        }
    }
}

@Composable
fun appVM(): AppVM {
    val context = androidx.compose.ui.platform.LocalContext.current
    return viewModel(factory = object: androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T: androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST") return AppVM(context.applicationContext) as T
        }
    })
}

@Composable
fun App() {
    val nav = rememberNavController()
    val vm = appVM()
    NavHost(nav, startDestination="home") {
        composable("home") { Home(nav) }
        composable("add") { AddActivityScreen(vm, nav) }
        composable("data") { DataScreen(vm, nav) }
        composable("report") { ReportScreen(vm, nav) }
        composable("signature") { SignatureScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("legacy") { LegacyScreen(vm, nav) }
    }
}

@Composable
fun Home(nav: androidx.navigation.NavHostController) {
    Scaffold { p ->
        Column(Modifier.padding(p).padding(28.dp), verticalArrangement=Arrangement.spacedBy(22.dp)) {
            Text("Drh Mandiri", style=MaterialTheme.typography.displaySmall, color=MaterialTheme.colorScheme.primary)
            Text("Laporan Kegiatan Dokter Hewan Mandiri", style=MaterialTheme.typography.headlineSmall)
            HomeButton("＋ Tambah Kegiatan", Icons.Default.Add) { nav.navigate("add") }
            HomeButton("☷ Data Kegiatan", Icons.Default.List) { nav.navigate("data") }
            HomeButton("▣ Buat Laporan", Icons.Default.Description) { nav.navigate("report") }
            HomeButton("✍ Tanda Tangan Dokter", Icons.Default.Edit) { nav.navigate("signature") }
            HomeButton("▣ Arsip JPG Lama", Icons.Default.Image) { nav.navigate("legacy") }
            HomeButton("⚙ Pengaturan & Backup", Icons.Default.Settings) { nav.navigate("settings") }
            Spacer(Modifier.height(8.dp))
            Text("Data disimpan di perangkat. Gunakan Cadangkan untuk menyimpan salinan data.", style=MaterialTheme.typography.bodyLarge)
        }
    }
}
@Composable fun HomeButton(text:String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit) {
    Button(onClick=onClick, modifier=Modifier.fillMaxWidth().height(68.dp), shape=MaterialTheme.shapes.extraLarge) {
        Icon(icon,null); Spacer(Modifier.width(10.dp)); Text(text, style=MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun AddActivityScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    val scope=rememberCoroutineScope(); var title by remember{mutableStateOf("")}; var location by remember{mutableStateOf("")}; var desc by remember{mutableStateOf("")}
    var date by remember{mutableStateOf(System.currentTimeMillis())}; var msg by remember{mutableStateOf<String?>(null)}
    val context=androidx.compose.ui.platform.LocalContext.current
    ScreenTitle("Tambah Kegiatan",nav) {
        OutlinedTextField(title,{title=it},label={Text("Nama kegiatan *")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(location,{location=it},label={Text("Lokasi")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(desc,{desc=it},label={Text("Keterangan")},modifier=Modifier.fillMaxWidth(),minLines=4)
        Button(onClick={
            val c=Calendar.getInstance(); c.timeInMillis=date
            DatePickerDialog(context,{_,y,m,d-> c.set(y,m,d); date=c.timeInMillis },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
        }) { Text("Tanggal: "+SimpleDateFormat("dd-MM-yyyy",Locale.US).format(Date(date))) }
        Button(onClick={ scope.launch { runCatching{vm.saveActivity(date,title,location,desc)}.onSuccess { msg="Kegiatan berhasil disimpan"; title="";location="";desc="" }.onFailure{msg=it.message} } },modifier=Modifier.fillMaxWidth()) { Text("Simpan Kegiatan") }
        msg?.let { Text(it,color=if(it.contains("berhasil")) Color(0xFF16803C) else Color.Red) }
    }
}

@Composable
fun DataScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    val list by vm.activities.collectAsState(initial=emptyList()); val scope=rememberCoroutineScope()
    Scaffold(topBar={TopAppBar(title={Text("Data Kegiatan")},navigationIcon={IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)}})}){p->
        LazyColumn(Modifier.padding(p).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(list,key={it.id}){a-> Card{Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(a.title,style=MaterialTheme.typography.titleMedium);Text(SimpleDateFormat("dd-MM-yyyy",Locale.US).format(Date(a.dateMillis))); if(a.location.isNotBlank())Text(a.location); if(a.description.isNotBlank())Text(a.description)};IconButton({scope.launch{vm.deleteActivity(a)}}){Icon(Icons.Default.Delete,null)}}}}
        }
    }
}

@Composable
fun ReportScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    var from by remember{mutableStateOf(currentMonth())}; var to by remember{mutableStateOf(currentMonth())}; var result by remember{mutableStateOf("")}; val scope=rememberCoroutineScope()
    ScreenTitle("Buat Laporan",nav) {
        Text("Pilih bulan awal dan bulan akhir. Setiap bulan akan dibuat pada halaman baru, tidak disambung di bawah bulan sebelumnya.")
        OutlinedTextField(from,{from=it},label={Text("Dari bulan (YYYY-MM)")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(to,{to=it},label={Text("Sampai bulan (YYYY-MM)")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({scope.launch{result=runCatching{vm.report(from,to,"JPG")}.getOrElse{it.message?:"Gagal"}.toString()}}){Text("JPG")};Button({scope.launch{result=runCatching{vm.report(from,to,"PDF")}.getOrElse{it.message?:"Gagal"}.toString()}}){Text("PDF")};Button({scope.launch{result=runCatching{vm.report(from,to,"DOC")}.getOrElse{it.message?:"Gagal"}.toString()}}){Text("DOC")}}
        if(result.isNotBlank()) Text("Output: $result")
        Text("Tanda tangan yang sudah disimpan akan dicantumkan otomatis pada laporan.")
    }
}

@Composable
fun SignatureScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    val scope=rememberCoroutineScope(); val paths=remember{mutableStateListOf<Path>()}; var current by remember{mutableStateOf<Path?>(null)}; var saved by remember{mutableStateOf("")}
    ScreenTitle("Tanda Tangan Dokter",nav) {
        Text("Tulis tanda tangan di area putih. Setelah disimpan, kembali ke Buat Laporan untuk memilih satu atau beberapa bulan.")
        Canvas(Modifier.fillMaxWidth().height(280.dp).background(Color.White).pointerInput(Unit){
            awaitPointerEventScope { while(true){ val e=awaitPointerEvent(); val ch=e.changes.firstOrNull()?:continue; val pos=ch.position; if(ch.pressed){ if(current==null){current=Path().apply{moveTo(pos.x,pos.y)};paths.add(current!!)}else current?.lineTo(pos.x,pos.y);ch.consume()} else current=null } }
        }){ paths.forEach{drawPath(it,Color.Black,style=androidx.compose.ui.graphics.drawscope.Stroke(5f))} }
        Row{Button({paths.clear();current=null}){Text("Hapus")};Spacer(Modifier.width(10.dp));Button({scope.launch{val bmp=Bitmap.createBitmap(1000,500,Bitmap.Config.ARGB_8888);val c=Canvas(bmp);c.drawColor(android.graphics.Color.WHITE);val paint=Paint().apply{color=android.graphics.Color.BLACK;strokeWidth=5f;style=Paint.Style.STROKE;isAntiAlias=true};paths.forEach{c.drawPath(it.asAndroidPath(),paint)};vm.saveSignature(bmp);saved="Tanda tangan berhasil disimpan"}}){Text("Simpan Tanda Tangan")}}
        if(saved.isNotBlank())Text(saved)
    }
}

@Composable
fun SettingsScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    val context=androidx.compose.ui.platform.LocalContext.current; val scope=rememberCoroutineScope(); var name by remember{mutableStateOf("")};var reg by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")}
    val backupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){u->u?.let{scope.launch{vm.backup(it);msg="Backup berhasil dibuat"}}}
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{scope.launch{vm.restore(it);msg="Data berhasil dipulihkan"}}}
    ScreenTitle("Pengaturan Dokter & Backup",nav) {
        OutlinedTextField(name,{name=it},label={Text("Nama Dokter")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(reg,{reg=it},label={Text("Nomor registrasi / SIP")},modifier=Modifier.fillMaxWidth())
        Button({scope.launch{vm.saveDoctor(name,reg);msg="Data dokter disimpan"}},modifier=Modifier.fillMaxWidth()){Text("Simpan Data Dokter")}
        Divider(); Text("Cadangkan & Pulihkan",style=MaterialTheme.typography.titleMedium)
        Button({backupLauncher.launch("Laporan_DRH_backup.json")},modifier=Modifier.fillMaxWidth()){Text("Cadangkan Data")}
        OutlinedButton({restoreLauncher.launch(arrayOf("application/json","text/*"))},modifier=Modifier.fillMaxWidth()){Text("Pulihkan Data")}
        if(msg.isNotBlank())Text(msg)
    }
}

@Composable
fun LegacyScreen(vm:AppVM, nav: androidx.navigation.NavHostController) {
    val scope=rememberCoroutineScope(); var month by remember{mutableStateOf(currentMonth())};var note by remember{mutableStateOf("")};var msg by remember{mutableStateOf("")}; val list by vm.legacy.collectAsState(initial=emptyList())
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{scope.launch{vm.importLegacy(it,month,note);msg="JPG lama berhasil diarsipkan"}}}
    ScreenTitle("Impor JPG Lama",nav) {
        Text("Masukkan output JPG dari aplikasi lama sebagai arsip kegiatan. Dengan cara ini laporan lama tetap aman dan dapat disimpan bersama data baru.")
        OutlinedTextField(month,{month=it},label={Text("Bulan laporan (YYYY-MM)")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(note,{note=it},label={Text("Catatan")},modifier=Modifier.fillMaxWidth())
        Button({launcher.launch(arrayOf("image/jpeg","image/jpg","image/*"))},modifier=Modifier.fillMaxWidth()){Text("Pilih File JPG")}
        if(msg.isNotBlank())Text(msg)
        Text("Arsip tersimpan: ${list.size}")
        list.forEach{Text("• ${it.monthKey} — ${it.note}")}
    }
}

@Composable
fun ScreenTitle(title:String,nav: androidx.navigation.NavHostController,content:@Composable ColumnScope.()->Unit) {
    Scaffold(topBar={TopAppBar(title={Text(title)},navigationIcon={IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)}})}){p->Column(Modifier.padding(p).padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)}
}
fun currentMonth()=SimpleDateFormat("yyyy-MM",Locale.US).format(Date())
